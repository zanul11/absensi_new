<?php

return [

    'roles' => [
        'super' => "Super Admin",
        'admin' => "Admin Aplikasi",
    ],
    'hari' => [
        '0' => "Minggu",
        '1' => "Senin",
        '2' => "Selasa",
        '3' => "Rabu",
        '4' => "Kamis",
        '5' => "Jumat",
        '6' => "Sabtu",
    ],

];
